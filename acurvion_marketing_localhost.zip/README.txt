ACURVION MARKETING WEBSITE — LOCALHOST SETUP

Files:
- index.html: Complete responsive website (HTML, CSS and JavaScript in one file)

Quick start:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open a terminal in that folder.
4. Run: python -m http.server 8000
5. Open: http://localhost:8000

If Python is not installed, you can double-click index.html to preview it in your browser.

Before publishing:
- Replace hello@acurvion.com with your real business email.
- The contact form currently opens the visitor's email app; connect a form backend or CRM to collect leads automatically.
- Add your final logo file, social links, privacy policy, and verified case studies/testimonials.
